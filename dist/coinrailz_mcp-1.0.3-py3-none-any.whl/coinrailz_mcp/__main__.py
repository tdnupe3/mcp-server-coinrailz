#!/usr/bin/env python3
"""Entry point for running coinrailz-mcp as a module."""

from . import main

if __name__ == "__main__":
    main()
